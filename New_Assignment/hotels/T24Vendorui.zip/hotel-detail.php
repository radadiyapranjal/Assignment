<?php include("header.php");
error_reporting(E_ALL);
ini_set('display_errors', 1);


?>

  <?php
  $id=$_GET["id"];
                    $service=mysqli_query($conn2,"select * from service_hotels where status='active' and id='$id' order by id desc");

                   //echo mysqli_error($conn2);
                    $services=mysqli_fetch_array($service);
                        $vendor=mysqli_query($conn2,"select * from vendor_service where status='active' and service_name='".$services["hotel_name"]."' order by id desc");
                        $vendors=mysqli_fetch_array($vendor);


                        $vendor1=mysqli_query($conn2,"select * from vendor where uid='".$services["vendor_uid"]."' order by id desc");
                        $vendors1=mysqli_fetch_array($vendor1);
                    
// Capture form data
if (isset($_POST["add_to_cart"])) {
    $user_id =$_SESSION['user_id']; // Assuming user_id is 1, change this based on logged-in user
    $hotel_id = $id; // Assuming hotel_id is 1, change based on the selected hotel
    $guest = $_POST['guest'];
    $checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];
 $price_per_night = $_POST['price_per_night']; // Price per night

    // Calculate number of days between checkin and checkout
    $checkin_date = strtotime($checkin);
    $checkout_date = strtotime($checkout);
    
    if ($checkout_date <= $checkin_date) {
       // echo "Checkout date must be after check-in date.";

             echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>';
            echo '<script>
                Swal.fire({
                    icon: "error",
                    title: "Error!",
                    text: "Checkout date must be after check-in date.",
                }).then(function() {
                    window.location.href = "hotel-detail.php?id='.$id.'";  // Redirect to dashboard or any other page
                });
            </script>';
        exit;
    }
    
    $datediff = $checkout_date - $checkin_date;
    $days = round($datediff / (60 * 60 * 24)); // Convert seconds to days
    
    // Calculate total amount
    $total_amount = $days * $price_per_night;
            $check=mysqli_query($conn2,"select * from cart where hotel_id='$hotel_id' and user_id='$user_id'");
            $checks=mysqli_num_rows($check);
            if($checks>0){


             echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>';
            echo '<script>
                Swal.fire({
                    icon: "success",
                    title: "Success!",
                    text: "Already Added Hotel In Cart!",
                }).then(function() {
                    window.location.href = "hotel-detail.php?id='.$id.'";  // Redirect to dashboard or any other page
                });
            </script>';
  
            } else{
    // Insert data into the `cart` table, including the total amount
    $sql = "INSERT INTO cart (user_id, hotel_id, price, guest, checkin, checkout, total_amount) 
            VALUES ('$user_id', '$hotel_id', '$price_per_night', '$guest', '$checkin', '$checkout', '$total_amount')";

    if (mysqli_query($conn2, $sql)) {
        //echo "Booking successfully added to cart! Total Amount: $" . $total_amount;

             echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>';
            echo '<script>
                Swal.fire({
                    icon: "success",
                    title: "Success!",
                    text: "Booking successfully added to cart! Total Amount: ₹' . $total_amount.'",
                }).then(function() {
                    window.location.href = "hotel-detail.php?id='.$id.'";  // Redirect to dashboard or any other page
                });
            </script>';
    } else {
      //  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
      //  "Booking successfully added to cart! Total Amount: $" . $total_amount


             echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>';
            echo '<script>
                Swal.fire({
                    icon: "error",
                    title: "Error!",
                    text: "Error: ' . $sql . '<br>' . mysqli_error($conn2).'",
                }).then(function() {
                    window.location.href = "hotel-detail.php?id='.$id.'";  // Redirect to dashboard or any other page
                });
            </script>';
    }
} 

    // Close connection
//    mysqli_close($conn);
}



                    ?>
    <title>Hotel Details-Trip24</title>

    <style>
    .bg-white {
        --bs-bg-opacity: 1;
        background-color: #c7d7ff !important;
    }
</style>

<!-- ================================
         END HEADER AREA
================================= -->    <!-- ================================
    START BREADCRUMB AREA
================================= -->

    <style>
        .bread-bg {
            background-image: url(https://img.freepik.com/free-photo/landscape-with-colorful-rainbow-appearing-sky_23-2151521474.jpg?t=st=1724865143~exp=1724868743~hmac=d4a6ca523e55df725eb4368d41ffffb5626900c275745fc87ad793b2b9d70e67&w=1060);
        }
    </style>
    <section class="breadcrumb-area bread-bg">
        <div id="particles-js"></div>

        <!-- <div class="overlay"></div> -->
        <!-- end overlay -->
        <div class="container">
            <div class="breadcrumb-content text-center">
                <h2 class="sec__title text-white mb-3">Hotel Details</h2>
                <!-- <ul style="color: white;" class="bread-list text-dark">
                    <li><a href="index" style="color: white;" ;>Home</a></li>
                    <li style="color: white;" ;>Hotel Details</li>
                </ul> -->
            </div>
            <!-- end breadcrumb-content -->
        </div>
    </section>
    <!-- end breadcrumb-area -->


    <!-- ================================
    START CARD AREA
================================= -->
    <section class="card-area padding-top-60px padding-bottom-90px">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mb-4">
                    <div class="listing-wrapper">

                        <!-- end listing-single-panel -->
                        <div class="listing-single-panel mb-5">
                            <!-- <h4 class="font-size-20 font-weight-semi-bold mb-3">Photos</h4> -->
                            <div class="gallery-carousel owl-carousel owl-theme">
                                
                                <div class="gallery-item">
                                    <img src="../<?php echo $services["banner"];?>" alt="gallery-image" style="height:100%"/>
                                </div>
                                <?php 
                                $gallery=mysqli_query($conn2,"select * from service_hotel_gallery where hotel_id='$id'");
                                while($gallerys=mysqli_fetch_array($gallery)){
                                ?>
                                <div class="gallery-item">
                                    <img src="../<?php echo $gallerys["image"];?>" alt="gallery-image"  style="height:100%"/>
                                </div>
                            <?php } ?>
                               <!--  <div class="gallery-item">
                                    <img src="https://pix8.agoda.net/hotelImages/1147232/-1/1495ef0fd8db259d68eb8e81e9c03372.jpg?ca=20&ce=0&s=1024x" alt="gallery-image" />
                                </div>
                                <div class="gallery-item">
                                    <img src="https://pix8.agoda.net/hotelImages/1147232/-1/261d547ff6ba2cfa3392cf582d0e7800.jpg?ca=20&ce=0&s=1024x" alt="gallery-image" />
                                </div>
                                <div class="gallery-item">
                                    <img src="https://pix8.agoda.net/hotelImages/1147232/-1/c65bfec17e38846a04b9a05a57d2711f.jpg?ca=20&ce=0&s=1024x" alt="gallery-image" />
                                </div> -->

                            </div>
                        </div>
                        <!-- end listing-single-panel -->
                        <div class="listing-single-panel mb-5">
                            <div class="card col-lg-12">
                                <div class="card-body">
                                    <span class="badge  badge-pill" style='color:red; font-size:30px; float: right; '>&#8377;<?php echo $services["price"];?>/<span style="color:black; font-size:10px; ">&nbsp;<?php echo $services["price_unit"];?></span> </span>
                                    <!-- <button class="theme-btn border-0 w-30" type="submit" style="float:right; border-radius: 30px; ">
                                            View This Del
                                        </button> -->

                                    <h4 class="font-size-30 font-weight-semi-bold mb-4 card-title ">
                                    <?php echo $services["hotel_name"];?>
                                    </h4>
                                    <div class="row media mt-4">
                                        <p>
                                            <?php echo $vendors["service_address"]?> <?php echo $vendors["service_city"]?> , <?php echo $vendors["service_state"]?>-<?php echo $vendors["service_pincode"]?>
                                        </p>
                                    </div>
                                    <div class="row media mt-4">
                                        <h6>
                                            <?php echo $services["amenities"];?>
                                        </h6>
                                    </div>

                                </div>
                                <!-- end card-body -->
                            </div>

                            <!-- end row -->
                        </div>


                        <div class="listing-single-panel mb-5">
                            <div class="card">
                                <div class="card-body">
                            <h4 class="font-size-30 font-weight-semi-bold mb-3">
                                Features
                            </h4>
                            <div class="row">
                                <div class="col-lg-6 ">
                                    <ul class="list-items">
                                        <li>
                                            <img src="icons/wifi.png" height="26px;" alt="" srcset="">&nbsp;Room Type: <?php echo $services["room_type"];?></img> 

                                        </li>
                                        <li>
                                            <img src="icons/wifi.png" height="26px;" alt="" srcset="">&nbsp;Person ALlowed: <?php echo $services["person"];?></img> 

                                        </li>


                                    </ul>
                                </div>
                                <!-- end col-lg-4 -->

                            </div>
                            <!-- end row -->
                        </div>
                    </div>
                </div>


                        <div class="listing-single-panel mb-5">
                            <div class="card">
                                <div class="card-body">
                            <h4 class="font-size-30 font-weight-semi-bold mb-3">
                                 Contact Details
                            </h4>
                        <!--     <div
                                id="map-single"
                                data-latitude="32.243187"
                                data-longitude="77.189176"
                                class="w-100 height-300"></div> -->
                                <?php if(!empty($services["map"])){?>
                                     <iframe src="<?php echo $services["map"];?>" width="100%" height="350" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                               <?php } ?>
                       
                            <ul class="list-items mt-4">
                                <li>
                                    <span
                                        class="fal fa-map-marker-alt icon-element icon-element-sm bg-white shadow-sm text-black me-2 font-size-14"></span>
                                        <?php echo $vendors["service_address"]?> <?php echo $vendors["service_city"]?> , <?php echo $vendors["service_state"]?>-<?php echo $vendors["service_pincode"]?>
                                        
                                </li>
                                <li>
                                    <span
                                        class="fal fa-envelope icon-element icon-element-sm bg-white shadow-sm text-black me-2 font-size-14"></span><a href="mailto:<?php echo $vendors["service_email"];?>"><?php echo $vendors["service_email"];?></a>
                                </li>
                                <li>
                                    <span
                                        class="fal fa-phone icon-element icon-element-sm bg-white shadow-sm text-black me-2 font-size-14"></span><a href="tel:<?php echo $vendors["service_no"];?>">
                                    <?php echo $vendors["service_no"];?></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                <!-- end col-lg-8 -->
                <div class="col-lg-4">
                    <div class="sidebar">
                        <div
                            class="author-verified bg-success p-3 rounded text-white text-center mb-4"
                            data-bs-toggle="tooltip"
                            data-placement="top"
                            title="Listing has been verified and belongs the business owner or manager">
                            <i class="far fa-check me-2"></i>
                            Verified Listing
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title mb-3">Booking</h4>
                                 <form action="" method="POST">
        <div class="form-group">
            <span class="fal fa-calendar-alt form-icon"></span>

            <input class="form-control form--control date-picker" type="text" placeholder="Check-in Date" name="checkin" required />
        </div>
        <div class="form-group">
            <span class="fal fa-calendar-alt form-icon"></span>
            <input class="form-control form--control date-picker" type="text" placeholder="Check-out Date" name="checkout" required />
        </div>
       <!--  <div class="form-group">
            <span class="fal fa-user-alt form-icon"></span>
            <input class="form-control form--control" type="text" placeholder="Name" name="name" required />
        </div> -->
        <div class="quantity-wrap d-flex align-items-center justify-content-between mb-3">
            <p class="text-black"><i class="fal fa-user me-1"></i> Guest:</p>
            <div class="quantity-box d-flex align-items-center">
                <a href="javascript:void(0)" class="qtyBtn qtyDec"><i class="fal fa-minus"></i></a>
                <input class="qtyInput" type="number" name="guest" value="1" required />
                <a href="javascript:void(0)" class="qtyBtn qtyInc"><i class="far fa-plus"></i></a>
            </div>
        </div>

        <!-- Assume price per night is fixed for simplicity -->
        <input type="hidden" name="price_per_night" value="<?php echo $services["price"];?>" />
        <?php if(!empty($_SESSION['user_id'])){?>
        <button type="submit" class="theme-btn w-100" name="add_to_cart">Add to Cart</button>
    <?php } else{
        $_SESSION['hotel_id']=$id;
        ?>

    <a href="login.php" class="theme-btn w-100">Add to Cart</a>
    
    <?php } ?>
    </form>
                                <!-- <div class="form-group">
                                    <span class="fal fa-calendar-alt form-icon"></span>
                                    <input
                                        class="form-control form--control date-picker"
                                        type="text"
                                        placeholder="Date" />
                                </div>
                                <div class="form-group">
                                    <span class="fal fa-calendar-alt form-icon"></span>
                                    <input
                                        class="form-control form--control date-picker"
                                        type="text"
                                        placeholder="Date" />
                                </div>
                                <div class="form-group">
                                    <span class="fal fa-user-alt form-icon"></span>
                                    <input
                                        class="form-control form--control "
                                        type="text"
                                        placeholder="Name" />
                                </div>
                                <div
                                    class="quantity-wrap d-flex align-items-center justify-content-between mb-3">
                                    <p class="text-black">
                                        <i class="fal fa-user me-1"></i> Guest:
                                    </p>
                                    <div class="quantity-box d-flex align-items-center">
                                        <a href="javascript:void(0)" class="qtyBtn qtyDec"><i class="fal fa-minus"></i></a>
                                        <input
                                            class="qtyInput"
                                            type="text"
                                            name="qty-input"
                                            value="0" />
                                        <a href="javascript:void(0)" class="qtyBtn qtyInc"><i class="far fa-plus"></i></a>
                                    </div>
                                </div>
                                <!-- end quantity-wrap --
                                <a href="modify-your-booking" class="theme-btn w-100">Request To Book</a> -->
                            </div>
                            <!-- end card-body -->
                        </div>
                        <!-- end card --->
                        <!-- <div class="card">
                            <div class="card-body">
                              
                            </div>
                            <!-- end card-body --
                        </div> -->
<!-- 
                            <?php if(!empty( $services["map"])){?>
                        <div class="card">
                            <div class="card-body">
                               
                        <div class="listing-single-panel mb-5">
                            <h4 class="font-size-30 font-weight-semi-bold mb-3">
                                 Location Map
                            </h4>
                       
                        </div>
                            </div>
                            <!-- end card-body --
                        </div>

                         <?php } ?> -->

                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title mb-3">Vendor Details</h4>
                                <div class="media mt-4">
                                    <!-- <img
                                        src="images/small-team1.jpg"
                                        alt="avatar"
                                        class="user-avatar flex-shrink-0 me-3" /> -->
                                    <div class="media-body align-self-center" style="width:100%">
                                        <h4 class="font-size-18 font-weight-semi-bold mb-1" style="text-align:center;">
                                            <a href="user-modify-your-booking" class="btn-link text-black"><?php echo $vendors1["vendor_name"];?></a>
                                        </h4>
                                        <p style="
    color: #808996;
    font-size: 15px;
    font-weight: 500;
    text-align: center;
"> <?php echo $vendors1["business_name"];?> (<?php echo $vendors1["gst_no"];?>)</p>
                                       <ul class="list-items mt-4">
                                
                                 <li>
                                    <span
                                        class="fal fa-map-marker-alt icon-element icon-element-sm bg-white shadow-sm text-black me-2 font-size-14"></span>
                                        <?php echo $vendors1["address"]?> <?php echo $vendors1["city"]?> , <?php echo $vendors1["state"]?>-<?php echo $vendors1["pincode"]?>
                                        
                                </li>
                                <li>
                                    <span
                                        class="fal fa-envelope icon-element icon-element-sm bg-white shadow-sm text-black me-2 font-size-14"></span><a href="mailto:<?php echo $vendors1["email_id"];?>"><?php echo $vendors1["email_id"];?></a>
                                </li>
                                <li>
                                    <span
                                        class="fal fa-phone icon-element icon-element-sm bg-white shadow-sm text-black me-2 font-size-14"></span><a href="tel:<?php echo $vendors1["mobile_no"];?>">
                                    <?php echo $vendors1["mobile_no"];?></a>
                                </li>
                            </ul>
                                    </div>
                                </div>
                                <!-- <ul class="list-items mt-4">
                                    <li>
                                        <span
                                            class="fal fa-envelope icon-element icon-element-sm bg-white shadow-sm text-black me-2 font-size-14"></span><a href="mailto:rahul@gmail.com">rahul@gmail.com</a>
                                    </li>
                                    <li>
                                        <span
                                            class="fal fa-phone icon-element icon-element-sm bg-white shadow-sm text-black me-2 font-size-14"></span>
                                        +7(111)123456789
                                    </li>
                                </ul> -->
                            </div>
                            <!-- end card-body -->
                        </div>
                        <!-- end card -->
                    </div>
                    <!-- end sidebar -->
                </div>
                <!-- end col-lg-4 -->
            </div>
            <!-- end row -->
        </div>
        <!-- end container -->
    </section>
    <!-- end card-area -->
    <!-- ================================
    END CARD AREA
================================= -->

    <section class="footer-area bg-gray padding-top-80px pattern-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="footer-item">
                    <a href="index" class="footer-logo mb-4 d-inline-block">
                        <h2>Trip24</h2>
                    </a>
                    <p class="mb-4">
                        Discover the best travel deals, destinations, and experiences tailored for you. Whether you're planning a weekend getaway or a long vacation, Trip24 is your go-to travel companion.
                    </p>
                    <div class="social-icons">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="footer-item">
                    <h4 class="footer__title mb-3">Quick Links</h4>
                    <div class="stroke-shape mb-4"></div>
                    <ul class="list-items list-items-underline">
                        <li><a href="#">Help Center</a></li>
                        <li><a href="#">Terms & Conditions</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Return Policy</a></li>
                        <li><a href="#">Help Center</a></li>
                        <li><a href="contact">Contact Us</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="footer-item">
                    <h4 class="footer__title mb-3">Categories</h4>
                    <div class="stroke-shape mb-4"></div>
                    <ul class="list-items list-items-underline">
                        <li><a href="bike">Bike On Rent</a></li>
                        <li><a href="hotels">Hotels Book</a></li>
                        <li><a href="trip-packages">Trip Package</a></li>
                        <li><a href="#">Activities</a></li>
                        <li><a href="bus">Bus Ticket Book</a></li>
                        <li><a href="product">Products</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="footer-item">
                    <h4 class="footer__title mb-3">Contact with Us</h4>
                    <div class="stroke-shape mb-4"></div>
                    <ul class="info-list">
                        <li>
                            <span class="fal fa-home icon me-2"></span> 12345 Little Baker St, Melbourne Lorem ipsum dolor sit amet.
                        </li>
                        <li>
                            <span class="fal fa-headphones icon me-2"></span>
                            <a href="#">+ 61 23 8093 3400</a>
                        </li>
                        <li>
                            <span class="fal fa-envelope icon me-2"></span>
                            <a href="#">abc@gmail.com</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <hr class="border-top-gray" />
        <div class="copy-right d-flex flex-wrap align-items-center justify-content-between pb-4">
            <p class="copy__desc py-2">
                &copy; Copyright Trip24 <span id="copyright-year">2024</span>. All rights reserved.
            </p>
        </div>
    </div>

    <style>
        .bg-gray {
            background-color: #c7d7ff !important;
        }
    </style>
</section>    <!-- start back-to-top -->
    <div id="back-to-top">
        <i class="fal fa-angle-up" title="Go top"></i>
    </div>
    <!-- end back-to-top -->

    <!-- end modal -->
    <div
        class="modal fade modal-container"
        id="shareModal"
        tabindex="-1"
        role="dialog"
        aria-labelledby="shareModalTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header align-items-center">
                    <h5 class="modal-title" id="shareModalTitle">Share Business</h5>
                    <button
                        type="button"
                        class="btn-close close"
                        data-bs-dismiss="modal"
                        aria-label="Close">
                        <span aria-hidden="true" class="fal fa-times"></span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="d-flex align-items-center mb-3">
                        <button
                            class="theme-btn flex-grow-1 mx-1 bg-primary"
                            type="button">
                            <i class="fab fa-facebook-f me-2"></i> Share on Facebook
                        </button>
                        <button
                            class="theme-btn flex-grow-1 mx-1 bg-success"
                            type="button">
                            <i class="fab fa-twitter me-2"></i> Share on Twitter
                        </button>
                    </div>
                    <div class="copy-to-clipboard mb-3 mx-1">
                        <span class="text-success-message">Link Copied!</span>
                        <div class="input-group">
                            <input
                                type="text"
                                class="form-control form--control copy-input ps-3"
                                value="https://www.dirto.com/share/101WxMB0oac1hVQQ==/" />
                            <div class="input-group-append">
                                <a href="javascript:void(0)" class="theme-btn copy-btn">Copy</a>
                            </div>
                        </div>
                    </div>
                    <!-- end copy-to-clipboard -->
                    <div class="d-flex align-items-center mb-3">
                        <hr class="border-top-gray flex-grow-1" />
                        <span class="bg-white text-uppercase mx-2 font-size-14">or</span>
                        <hr class="border-top-gray flex-grow-1" />
                    </div>
                    <form method="post">
                        <div class="form-group">
                            <span class="fal fa-user form-icon"></span>
                            <input
                                type="text"
                                class="form-control form--control"
                                placeholder="Your name" />
                        </div>
                        <div class="form-group">
                            <span class="fal fa-envelope form-icon"></span>
                            <input
                                type="email"
                                class="form-control form--control"
                                placeholder="Your email" />
                        </div>
                        <div class="form-group">
                            <span class="fal fa-envelope form-icon"></span>
                            <input
                                type="email"
                                class="form-control form--control"
                                placeholder="To: Email address" />
                        </div>
                        <div class="form-group">
                            <textarea
                                class="form-control form--control ps-3"
                                rows="4"
                                name="message"
                                placeholder="Add a note (optional)"></textarea>
                        </div>
                        <button type="submit" class="theme-btn w-100">
                            Share <i class="fal fa-long-arrow-right ms-2"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div
        class="modal fade modal-container"
        id="reportModal"
        tabindex="-1"
        role="dialog"
        aria-labelledby="reportModalTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header align-items-center">
                    <h5 class="modal-title" id="reportModalTitle">Report Business</h5>
                    <button
                        type="button"
                        class="btn-close close"
                        data-bs-dismiss="modal"
                        aria-label="Close">
                        <span aria-hidden="true" class="fal fa-times"></span>
                    </button>
                </div>
                <div class="modal-body">
                    <p class="font-size-15 pb-3">
                        Flagged content is reviewed by Dirto staff to determine whether it
                        violates Terms of Service or Community Guidelines. If you have a
                        question or technical issue, please contact our
                        <a href="modify-your-booking" class="btn-link">Support team here <i class="fal fa-angle-right ms-1"></i></a>
                    </p>
                    <form method="post">
                        <div class="form-group select2-container-wrapper">
                            <label class="label-text">Issue type</label>
                            <select class="select-picker" data-width="100%" data-size="5">
                                <option value="0">Select an issue</option>
                                <option value="1">Inappropriate listing Content</option>
                                <option value="2">Inappropriate Behavior</option>
                                <option value="3">Dirto Policy Violation</option>
                                <option value="4">Spammy Content</option>
                                <option value="5">Rude behavior with customer</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="label-text">Issue details</label>
                            <textarea
                                class="form-control form--control ps-3"
                                rows="4"
                                name="message"
                                placeholder="Explain report issue as clear as possible"></textarea>
                        </div>
                        <button type="submit" class="theme-btn w-100">
                            Report Listing <i class="fal fa-long-arrow-right ms-2"></i>
                        </button>
                        <p class="font-size-13 pt-1 text-center">
                            <span class="text-warning">Warning:</span> You can be banned for
                            violent messages.
                        </p>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Template JS Files -->
    <script src="https://work.perceptionvita.in/trip24ui/js/jquery-3.7.1.min.js"></script>
    <script src="https://work.perceptionvita.in/trip24ui/js/bootstrap.bundle.min.js"></script>
    <script src="https://work.perceptionvita.in/trip24ui/js/select2.min.js"></script>
    <script src="https://work.perceptionvita.in/trip24ui/js/owl.carousel.min.js"></script>
    <script src="https://work.perceptionvita.in/trip24ui/js/jquery.lazy.min.js"></script>
    <script src="https://work.perceptionvita.in/trip24ui/js/jquery.fancybox.min.js"></script>
    <!-- Start google map -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC_my4aX1ULOXNZcIxmpBnJmVF7U544p2k"></script>
    <script src="https://work.perceptionvita.in/trip24ui/js/maps.js"></script>
    <!-- End google map -->
    <script src="https://work.perceptionvita.in/trip24ui/js/jquery.MultiFile.min.js"></script>
    <!-- Start Date range picker -->
    <script src="https://work.perceptionvita.in/trip24ui/js/moment.min.js"></script>
    <script src="https://work.perceptionvita.in/trip24ui/js/daterangepicker.min.js"></script>
    <!-- end Date range picker -->
    <script src="https://work.perceptionvita.in/trip24ui/js/rating-script.js"></script>
    <script src="https://work.perceptionvita.in/trip24ui/js/main.js"></script>
    <script src="https://work.perceptionvita.in/trip24ui/js/particles.min.js"></script>
    <script src="https://work.perceptionvita.in/trip24ui/js/particles-script.js"></script>

</body>


</html>