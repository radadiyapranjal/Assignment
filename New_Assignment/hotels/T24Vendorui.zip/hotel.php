<?php include("header.php");?>
    <section class="breadcrumb-area bread-bg">
        <div id="particles-js"></div>

        <!-- <div class="overlay"></div> -->
        <!-- end overlay -->
        <div class="container">
            <div class="breadcrumb-content text-center">
                <h2 class="sec__title text-white mb-3">Hotels</h2>

            </div>
            <!-- end breadcrumb-content -->
        </div>
    </section>
    <!-- end breadcrumb-area -->

<section class="card-area padding-top-60px padding-bottom-90px">
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <div class="sidebar">
                    <div class="card">
                        <div class="card-body">
                            <form method="get">
                                <h4 class="card-title mb-3">Search</h4>
                                <div class="form-group select2-container-wrapper">
                                    <input class="form-control form--control" name="search" type="text" placeholder="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : 'What are you looking for?'; ?>" />
                                </div>
                                <button class="theme-btn border-0 w-100" type="submit">Search</button>
                            </form>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-3">Price Range</h4>
                            <form method="get" class="d-flex align-items-center">
                                <div class="form-group me-2">
                                    <input name="from" class="form-control form--control ps-3" value="<?php echo isset($_GET['from']) ? htmlspecialchars($_GET['from']) : ''; ?>" type="number" placeholder="&#8377;999" />
                                </div>
                                <div class="form-group me-2">
                                    <input name="to" class="form-control form--control ps-3" value="<?php echo isset($_GET['to']) ? htmlspecialchars($_GET['to']) : ''; ?>" type="number" placeholder="&#8377;5999" />
                                </div>
                                <button class="theme-btn theme-btn-gray border-0 mb-3" type="submit">
                                    <i class="fal fa-angle-right"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <?php

                $limit = 2; // Number of results per page
                $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
                $offset = ($page - 1) * $limit;

                // Capture the search term and price range from the URL
                $searchTerm = isset($_GET['search']) ? mysqli_real_escape_string($conn2, $_GET['search']) : '';
                $priceFrom = isset($_GET['from']) ? (float)$_GET['from'] : 0;
                $priceTo = isset($_GET['to']) ? (float)$_GET['to'] : PHP_INT_MAX;

                // Prepare the SQL query to fetch active services
                $query = "SELECT * FROM service_hotels WHERE status='active'";

                // Add search conditions for hotel name and service type
                if (!empty($searchTerm)) {
                    $query .= " AND (hotel_name LIKE '%$searchTerm%' OR 
                        (SELECT service_type FROM vendor_service WHERE service_name=service_hotels.hotel_name) LIKE '%$searchTerm%' OR 
                        (SELECT service_address FROM vendor_service WHERE service_name=service_hotels.hotel_name) LIKE '%$searchTerm%' OR 
                        (SELECT service_city FROM vendor_service WHERE service_name=service_hotels.hotel_name) LIKE '%$searchTerm%' OR 
                        (SELECT service_state FROM vendor_service WHERE service_name=service_hotels.hotel_name) LIKE '%$searchTerm%')";
                }

                if ($priceFrom > 0 || $priceTo < PHP_INT_MAX) {
                    $query .= " AND price >= $priceFrom AND price <= $priceTo";
                }
                $query .= " ORDER BY id DESC LIMIT $limit OFFSET $offset";

                $service = mysqli_query($conn2, $query);

                // Check for errors in the query
                if (!$service) {
                    echo "Error: " . mysqli_error($conn2);
                }

                // Count total results for pagination
                $countQuery = "SELECT COUNT(*) FROM service_hotels WHERE status='active'";
                if (!empty($searchTerm)) {
                    $countQuery .= " AND (hotel_name LIKE '%$searchTerm%' OR 
                        (SELECT service_type FROM vendor_service WHERE service_name=service_hotels.hotel_name) LIKE '%$searchTerm%' OR 
                        (SELECT service_address FROM vendor_service WHERE service_name=service_hotels.hotel_name) LIKE '%$searchTerm%' OR 
                        (SELECT service_city FROM vendor_service WHERE service_name=service_hotels.hotel_name) LIKE '%$searchTerm%' OR 
                        (SELECT service_state FROM vendor_service WHERE service_name=service_hotels.hotel_name) LIKE '%$searchTerm%')";
                }
                if ($priceFrom > 0 || $priceTo < PHP_INT_MAX) {
                    $countQuery .= " AND price >= $priceFrom AND price <= $priceTo";
                }
                $result = mysqli_query($conn2, $countQuery);
                $totalCount = mysqli_fetch_row($result)[0];
                $totalPages = ceil($totalCount / $limit);

                // Display services or message if none found
                if (mysqli_num_rows($service) > 0) {
                    while ($services = mysqli_fetch_array($service)) {
                        $vendor = mysqli_query($conn2, "SELECT * FROM vendor_service WHERE status='active' AND service_name='" . $services["hotel_name"] . "' ORDER BY id DESC");
                        $vendors = mysqli_fetch_array($vendor);
                ?>
                    <div class="listing-wrapper">
                        <div class="card card-flex">
                            <a href="hotel-detail.php?id=<?php echo $services["id"]; ?>" class="card-image">
                                <img src="../<?php echo $services["banner"]; ?>" class="card-img-top" alt="card image" />
                                <span class="badge text-bg-info badge-pill"><?php echo $vendors["service_type"]; ?></span>
                            </a>
                            <div class="card-body">
                                <div class="d-flex align-items-center mb-1">
                                    <h4 class="card-title mb-0">
                                        <a href="hotel-view-details"><?php echo $services["hotel_name"]; ?></a>
                                    </h4>
                                    <i class="fa fa-check-circle ms-1 text-success" data-bs-toggle="tooltip" data-placement="top" title="Claimed"></i>
                                </div>
                                <p class="card-text"><?php echo $vendors["service_address"] ?> <?php echo $vendors["service_city"] ?> , <?php echo $vendors["service_state"] ?>-<?php echo $vendors["service_pincode"] ?></p>
                                <!--  <ul class="info-list mt-3">
                                    <li>
                                        <img src="icons/wifi.png" height="26px;" alt="">&nbsp;Wifi &nbsp;
                                        <img src="icons/air-conditioner.png" height="26px;" alt="">&nbsp;AC &nbsp;
                                        <img src="icons/smart-tv.png" height="26px;" alt="">&nbsp;TV
                                    </li>
                                </ul>  -->
                                <div class="d-flex justify-content-between align-items-center mt-3">
                                    <span class="price">
                                        <h5><b>&#8377;<?php echo $services["price"]; ?></b></h5>
                                        <p style="color:#808996;font-size: 15px;font-weight: 500"><?php echo $services["price_unit"];?></p>
                                            </span>
                                </div>
                                <div class="d-flex align-items-end mt-3" style="float: right;">
                                    <button onclick="window.location.href='hotel-detail.php?id=<?php echo $services["id"]; ?>';" class="btn btn-info btn-sm">View Details</button>&nbsp;
                                  <?php if(isset($_SESSION['user_id'])){?>
       <!--  <form method="post" action="">
            <input type="hidden" name="hotel_id" value="<?php echo $services["id"]; ?>">
            <button type="submit" name="add_to_cart<?php echo $services["id"]; ?>" class="btn btn-success btn-sm">Book Now</button>
        </form> -->
        <?php

        // Handle the "add to cart" functionality if the user clicks "Book Now"
if (isset($_POST['add_to_cart'.$services["id"]])) {
    // Ensure the user is logged in
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        $hotel_id = mysqli_real_escape_string($conn2, $_POST['hotel_id']);
        
        // Check if the hotel is already in the cart for the user
        $checkCartQuery = "SELECT * FROM cart WHERE user_id='$user_id' AND hotel_id='$hotel_id'";
        $cartResult = mysqli_query($conn2, $checkCartQuery);
        
        if (mysqli_num_rows($cartResult) == 0) {
            // Insert new cart item if it doesn't exist
            $insertCartQuery = "INSERT INTO cart (user_id, hotel_id, quantity) VALUES ('$user_id', '$hotel_id', 1)";
            $insertResult = mysqli_query($conn2, $insertCartQuery);

            if ($insertResult) {
                echo "<script>alert('Hotel added to cart successfully!');</script>";
            } else {
                echo "<script>alert('Error adding to cart: " . mysqli_error($conn2) . "');</script>";
            }
        } else {
            // If already in cart, you may want to alert the user
            echo "<script>alert('Hotel is already in your cart.');</script>";
        }
    } else {
        // Redirect to login if user is not logged in
        header('Location: login.php');
        exit();
    }
}?>
    <?php } else { ?>
        <button onclick="window.location.href='login';" class="btn btn-success btn-sm">Book Now</button>
    <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php 
                    } 
                } else {
                ?>
                    <div class="alert alert-warning text-center" role="alert" style="margin-top: 20px;">
                        <h5>No results found for your search.</h5>
                        <p>Please try different search criteria.</p>
                    </div>
                <?php 
                }
                ?>

                <div class="pagination">
                    <?php
                    for ($i = 1; $i <= $totalPages; $i++) {
                        echo '<a href="?page=' . $i;
                        if (!empty($searchTerm)) {
                            echo '&search=' . urlencode($searchTerm);
                        }
                        if (isset($_GET["from"]) || isset($_GET["to"])) {
                            echo '&from=' . $priceFrom . '&to=' . $priceTo;
                        }
                        echo '">' . $i . '</a> ';
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
    .alert {
        padding: 15px;
        border: 1px solid #f0ad4e;
        border-radius: 5px;
        background-color: #fcf8e3;
        color: #856404;
    }
    .pagination {
        display: flex;
        justify-content: center;
        margin: 20px 0;
    }
    .pagination a {
        display: inline-block;
        padding: 10px 15px;
        margin: 0 5px;
        border: 1px solid #007bff;
        border-radius: 5px;
        color: #007bff;
        text-decoration: none;
        transition: background-color 0.3s, color 0.3s;
    }
    .pagination a:hover {
        background-color: #007bff;
        color: #ffffff;
    }
    .pagination a.active {
        background-color: #007bff;
        color: #ffffff;
        border-color: #007bff;
    }
    .pagination a.disabled {
        color: #ccc;
        border-color: #ccc;
        pointer-events: none;
    }
</style>

<?php include 'footer.php';?>
