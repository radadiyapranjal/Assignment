        <!-- Footer Section Starts -->
        <footer class="main-footer">
            <div class="pull-right hidden-xs">
                <!-- Version 1.0.0 -->
            </div>
            <p class="mb-0">Copyright © 2024 <a target="_blank" href="#">Trip24</a>. All rights
                reserved.</p>
        </footer>
        <!-- Footer Section Ends -->